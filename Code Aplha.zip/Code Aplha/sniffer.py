import socket
import struct
import sys

#  Replace this with your local IP from ipconfig
HOST = '192.168.1.108'

# IP header parsing function
def parse_ip_header(data):
    iph = struct.unpack('!BBHHHBBH4s4s', data[:20])
    version_ihl = iph[0]
    version = version_ihl >> 4
    ihl = version_ihl & 0xF
    iph_length = ihl * 4
    ttl = iph[5]
    protocol = iph[6]
    src_ip = socket.inet_ntoa(iph[8])
    dst_ip = socket.inet_ntoa(iph[9])

    return {
        'version': version,
        'header_length': iph_length,
        'ttl': ttl,
        'protocol': protocol,
        'src_ip': src_ip,
        'dst_ip': dst_ip,
        'data': data[iph_length:]
    }

# Protocol lookup
def get_protocol_name(proto):
    protocols = {1: 'ICMP', 6: 'TCP', 17: 'UDP'}
    return protocols.get(proto, f"Unknown ({proto})")

# Main sniffer function
def start_sniffer():
    try:
        # Create a raw socket
        sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        sniffer.bind((HOST, 0))

        # Include IP headers
        sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

        # Enable promiscuous mode
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)

        print(f"[+] Sniffing started on {HOST}...\n")

        while True:
            raw_data, addr = sniffer.recvfrom(65565)
            ip = parse_ip_header(raw_data)

            print(f"[+] Packet: {ip['src_ip']} -> {ip['dst_ip']} | Protocol: {get_protocol_name(ip['protocol'])}")
            print(f"    TTL: {ip['ttl']}, IP Version: {ip['version']}")
            print(f"    Raw Payload: {ip['data'][:16]}")
            print("-" * 60)

    except KeyboardInterrupt:
        print("\n[!] Sniffer stopped by user.")
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)
        sys.exit()

    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit()

if __name__ == "__main__":
    start_sniffer()

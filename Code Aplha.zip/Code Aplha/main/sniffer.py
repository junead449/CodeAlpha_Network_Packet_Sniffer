import socket
import struct
import sys
from datetime import datetime

# Replace with your actual local IP address from ipconfig
HOST = '192.168.1.108'
LOG_FILE = 'sniffer_log.txt'

def write_to_log(content):
    with open(LOG_FILE, 'a') as log:
        log.write(content + '\n')

def get_protocol_name(proto):
    protocols = {1: 'ICMP', 6: 'TCP', 17: 'UDP'}
    return protocols.get(proto, f"Unknown ({proto})")

# Parse IP Header
def parse_ip_header(data):
    iph = struct.unpack('!BBHHHBBH4s4s', data[:20])
    version = iph[0] >> 4
    ihl = (iph[0] & 0xF) * 4
    ttl = iph[5]
    proto = iph[6]
    src_ip = socket.inet_ntoa(iph[8])
    dst_ip = socket.inet_ntoa(iph[9])
    return {
        'version': version,
        'header_length': ihl,
        'ttl': ttl,
        'protocol': proto,
        'src_ip': src_ip,
        'dst_ip': dst_ip,
        'data': data[ihl:]
    }

# Parse TCP Header
def parse_tcp_header(data):
    tcph = struct.unpack('!HHLLHHHH', data[:20])
    src_port = tcph[0]
    dst_port = tcph[1]
    sequence = tcph[2]
    acknowledgement = tcph[3]
    offset = (tcph[4] >> 12) * 4
    return {
        'src_port': src_port,
        'dst_port': dst_port,
        'sequence': sequence,
        'acknowledgement': acknowledgement,
        'header_length': offset,
        'data': data[offset:]
    }

# Parse UDP Header
def parse_udp_header(data):
    udph = struct.unpack('!HHHH', data[:8])
    src_port = udph[0]
    dst_port = udph[1]
    length = udph[2]
    return {
        'src_port': src_port,
        'dst_port': dst_port,
        'length': length,
        'data': data[8:]
    }

# Start Sniffer
def start_sniffer():
    try:
        sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        sniffer.bind((HOST, 0))
        sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)

        print(f"[+] Sniffer started on {HOST}")
        write_to_log("=== Packet Log Started at " + str(datetime.now()) + " ===")

        while True:
            raw_data, addr = sniffer.recvfrom(65565)
            ip = parse_ip_header(raw_data)
            proto_name = get_protocol_name(ip['protocol'])

            log = f"\n[IP] {ip['src_ip']} -> {ip['dst_ip']} | Protocol: {proto_name}, TTL: {ip['ttl']}"

            if ip['protocol'] == 6:  # TCP
                tcp = parse_tcp_header(ip['data'])
                log += (f"\n   [TCP] Src Port: {tcp['src_port']}, Dst Port: {tcp['dst_port']}, "
                        f"Seq: {tcp['sequence']}, Ack: {tcp['acknowledgement']}")
            elif ip['protocol'] == 17:  # UDP
                udp = parse_udp_header(ip['data'])
                log += (f"\n   [UDP] Src Port: {udp['src_port']}, Dst Port: {udp['dst_port']}, "
                        f"Length: {udp['length']}")
            else:
                log += "\n   [!] Other Protocol (Not parsed in detail)"

            print(log)
            write_to_log(log)

    except KeyboardInterrupt:
        print("\n[!] Sniffer stopped by user.")
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)
        write_to_log("=== Packet Log Ended at " + str(datetime.now()) + " ===")
        sys.exit()

    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit()

if __name__ == "__main__":
    start_sniffer()
